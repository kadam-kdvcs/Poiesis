package org.kdvcs.poiesis.screen.layout;

import net.minecraft.resources.ResourceLocation;
import org.kdvcs.poiesis.Poiesis;
import org.kdvcs.poiesis.machine.module.MechanicalMode;

/**
 * Shared visual metadata for the Mechanical Processor's process indicator.
 *
 * Each mode has two layers:
 *  - BASE: static process-arrow backing
 *  - PROGRESS: foreground arrow, clipped/animated from left to right
 *
 * Both the real machine screen and JEI read these definitions, so UVs and
 * clickable bounds stay in sync.
 */
public final class MechanicalProcessorGuiLayout {

    public static final ResourceLocation BASE_TEXTURE =
            new ResourceLocation(
                    Poiesis.MOD_ID,
                    "textures/container/widget/mechanical_processor_base.png"
            );

    public static final ResourceLocation PROGRESS_TEXTURE =
            new ResourceLocation(
                    Poiesis.MOD_ID,
                    "textures/container/widget/mechanical_processor_progress_arrows.png"
            );

    public static final int BASE_TEXTURE_WIDTH = 22;
    public static final int BASE_TEXTURE_HEIGHT = 48;

    public static final int PROGRESS_TEXTURE_WIDTH = 22;
    public static final int PROGRESS_TEXTURE_HEIGHT = 48;

    private static final ProgressVisual PRESSING =
            new ProgressVisual(
                    78,
                    35,
                    new SpriteRegion(
                            0,
                            0,
                            22,
                            15
                    ),
                    new SpriteRegion(
                            0,
                            0,
                            22,
                            15
                    )
            );

    private static final ProgressVisual EXTRUSION =
            new ProgressVisual(
                    79,
                    34,
                    new SpriteRegion(
                            0,
                            15,
                            20,
                            15
                    ),
                    new SpriteRegion(
                            0,
                            15,
                            20,
                            15
                    )
            );

    private static final ProgressVisual GRINDING =
            new ProgressVisual(
                    79,
                    34,
                    new SpriteRegion(
                            0,
                            31,
                            19,
                            16
                    ),
                    new SpriteRegion(
                            0,
                            31,
                            19,
                            17
                    )
            );

    public static ProgressVisual progressVisual(
            MechanicalMode mode
    ) {
        return switch (mode) {
            case PRESSING -> PRESSING;
            case GRINDING -> GRINDING;
            case EXTRUSION -> EXTRUSION;
            case NONE -> null;
        };
    }

    public record SpriteRegion(
            int u,
            int v,
            int width,
            int height
    ) {
    }

    public record ProgressVisual(
            int x,
            int y,
            SpriteRegion base,
            SpriteRegion progress
    ) {
        public int width() {
            return Math.max(
                    base.width(),
                    progress.width()
            );
        }

        public int height() {
            return Math.max(
                    base.height(),
                    progress.height()
            );
        }
    }

    private MechanicalProcessorGuiLayout() {
    }
}
