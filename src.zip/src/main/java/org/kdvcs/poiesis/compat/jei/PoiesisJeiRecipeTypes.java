package org.kdvcs.poiesis.compat.jei;

import mezz.jei.api.recipe.RecipeType;
import org.kdvcs.poiesis.Poiesis;
import org.kdvcs.poiesis.recipe.MechanicalProcessingRecipe;

/**
 * JEI recipe types are deliberately separate from Minecraft RecipeType.
 *
 * MechanicalProcessingRecipe is one Minecraft recipe type, but JEI exposes
 * each processor specialization as its own page so recipe discovery matches
 * the way the machine is actually used.
 */
public final class PoiesisJeiRecipeTypes {

    public static final RecipeType<MechanicalProcessingRecipe> PRESSING =
            RecipeType.create(
                    Poiesis.MOD_ID,
                    "mechanical_processor/pressing",
                    MechanicalProcessingRecipe.class
            );

    public static final RecipeType<MechanicalProcessingRecipe> GRINDING =
            RecipeType.create(
                    Poiesis.MOD_ID,
                    "mechanical_processor/grinding",
                    MechanicalProcessingRecipe.class
            );

    public static final RecipeType<MechanicalProcessingRecipe> EXTRUSION =
            RecipeType.create(
                    Poiesis.MOD_ID,
                    "mechanical_processor/extrusion",
                    MechanicalProcessingRecipe.class
            );

    private PoiesisJeiRecipeTypes() {
    }
}
